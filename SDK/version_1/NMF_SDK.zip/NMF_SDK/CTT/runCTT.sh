#!/bin/sh

java -classpath CTT-jar-with-dependencies.jar esa.mo.nmf.ctt.guis.ConsumerTestToolGUI
