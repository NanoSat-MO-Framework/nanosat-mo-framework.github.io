There are two types of documents in this folder.

CCSDS Recommended Standards:
* CCSDS_MO_COM.pdf
* CCSDS_MO_MC.pdf
* CCSDS_MO_Common_draft_5.pdf

NMF bespoke services:
* ServiceSpecPlatform.pdf
* ServiceSpecSoftwareManagement.pdf


Please notice that the NMF bespoke services were automatically generated from the corresponding XML file.
